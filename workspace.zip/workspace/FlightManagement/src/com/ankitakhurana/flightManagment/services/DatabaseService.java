package com.ankitakhurana.flightManagment.services;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;

import com.ankitakhurana.flightManagement.models.Flight;
import com.ankitakhurana.flightManagement.models.SearchParams;
import com.ankitakhurana.flightManagement.models.User;
import com.ankitakhurana.flightManagement.utils.HibernateUtil;

public class DatabaseService {

	public static User GetUser(String username, String password) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		String hql = "select U.id, U.username, U.password from User U where U.username = :username and U.password = :password";
		Query query = session.createQuery(hql);
		query.setParameter("username", username);
		query.setParameter("password", password);
		Object[] result = (Object[]) query.getSingleResult();
		User u = new User();
		u.setId((int) result[0]);
		u.setUsername((String) result[1]);
		u.setPassword((String) result[2]);
		session.getTransaction().commit();
		session.close();
		return u;
	}

	public static List<Flight> listFlightDetails(SearchParams searchParams) {
		Session session = HibernateUtil.getSession();
		final String hql = "SELECT F FROM Flights F where F.arrLoc = :arrLoc and F.depLoc = :depLoc";
		final Query query = session.createQuery(hql);
		query.setParameter("arrLoc", searchParams.getArrLoc());
		query.setParameter("depLoc", searchParams.getDepLoc());
		@SuppressWarnings("unchecked")
		List<Flight> flightDetails = query.getResultList();
		return flightDetails;
	}
}
