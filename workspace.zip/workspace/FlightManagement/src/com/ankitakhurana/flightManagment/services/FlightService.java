package com.ankitakhurana.flightManagment.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.ankitakhurana.flightManagement.enums.FlightClassType;
import com.ankitakhurana.flightManagement.enums.Preference;
import com.ankitakhurana.flightManagement.models.Flight;
import com.ankitakhurana.flightManagement.models.SearchParams;

public class FlightService {

	public static List<Flight> getFlights(SearchParams searchParams) {
		List<Flight> flightDetails = DatabaseService.listFlightDetails(searchParams);
		final SearchParams sp = searchParams;
		if (flightDetails == null) {
			System.out.println("No flights available");
			return Collections.emptyList();
		}

		Predicate<Flight> flightPredicate = (fD -> fD.getValidTill().compareTo(sp.getFlightDate()) >= 0
				&& "Y".equals(fD.getSeatAvail()) && fD.getFlightClass().equals(sp.getFlightClass()));
		List<Flight> list = flightDetails.stream().filter(flightPredicate).map(fd -> {
			if (FlightClassType.EB.equals(FlightClassType.valueOf(searchParams.getFlightClass()))) {
				fd.setFare((float) (fd.getFare() * 1.40));
			}
			return fd;
		}).collect(Collectors.toList());

		List<Flight> res = new ArrayList<>();
		if (list.size() == 0)
			System.out.println("No Flights Available");
		else
			res = sortFlights(list, searchParams);
		return res;
	}

	public static List<Flight> sortFlights(List<Flight> matchedFlights, SearchParams searchParams) {
		if (Preference.FARE.equals(Preference.valueOf(searchParams.getPreference()))) {
			Collections.sort(matchedFlights, Comparator.comparingDouble(Flight::getFare));
		} else {
			Collections.sort(matchedFlights, Comparator.comparingDouble(Flight::getFare));
			Collections.sort(matchedFlights, Comparator.comparing(Flight::getFlightDur));
		}
		return matchedFlights;
	}

}
