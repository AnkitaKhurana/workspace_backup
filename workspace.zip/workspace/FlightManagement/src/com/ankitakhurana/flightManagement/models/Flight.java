package com.ankitakhurana.flightManagement.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="Flights")
public class Flight {

	@Id
	@Column(name = "flightNo")
	private String flightNo;

	@Column(name = "depLoc")
	private String depLoc;

	public String getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	public String getDepLoc() {
		return depLoc;
	}

	public void setDepLoc(String depLoc) {
		this.depLoc = depLoc;
	}

	public String getArrLoc() {
		return arrLoc;
	}

	public void setArrLoc(String arrLoc) {
		this.arrLoc = arrLoc;
	}

	public Date getValidTill() {
		return validTill;
	}

	public void setValidTill(Date validTill) {
		this.validTill = validTill;
	}

	public String getFlightTime() {
		return flightTime;
	}

	public void setFlightTime(String flightTime) {
		this.flightTime = flightTime;
	}

	public String getFlightDur() {
		return flightDur;
	}

	public void setFlightDur(String flightDur) {
		this.flightDur = flightDur;
	}

	public float getFare() {
		return fare;
	}

	public void setFare(float fare) {
		this.fare = fare;
	}

	public String getSeatAvail() {
		return seatAvail;
	}

	public void setSeatAvail(String seatAvail) {
		this.seatAvail = seatAvail;
	}

	public String getFlightClass() {
		return flightClass;
	}

	public void setFlightClass(String flightClass) {
		this.flightClass = flightClass;
	}

	@Column(name = "arrLoc")
	private String arrLoc;

	@Column(name = "validTill")
	private Date validTill;

	@Column(name = "flightTime")
	private String flightTime;

	@Column(name = "flightDur")
	private String flightDur;

	@Column(name = "fare")
	private float fare;

	@Column(name = "seatAvail")
	private String seatAvail;

	@Column(name = "class1")
	private String flightClass;

}
