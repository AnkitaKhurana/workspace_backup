package com.ankitakhurana.flightManagement.models;

import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

public class SearchParams {

	@Size(min = 3, max = 3)
	@NotNull(message = "Please enter Dept -3 letters")
	private String depLoc;

	@Size(min = 3, max = 3)
	@NotNull(message = "Please enter Arrival -3 letters")
	private String arrLoc;

	@DateTimeFormat(pattern = "dd-mm-yyyy")
	@NotNull
	private Date flightDate;

	@NotNull
	private String flightClass;

	private String preference;

	/**
	 * get Departure location of flight
	 * 
	 * @return departure location
	 */
	public String getDepLoc() {
		return depLoc;
	}

	/**
	 * set departure location
	 * 
	 * @param departure
	 *            location
	 */
	public void setDepLoc(String depLoc) {
		this.depLoc = depLoc;
	}

	/**
	 * get arrival location
	 * 
	 * @return arrival location
	 */
	public String getArrLoc() {
		return arrLoc;
	}

	/**
	 * set arrival location
	 * 
	 * @param arrival
	 *            location
	 */
	public void setArrLoc(String arrLoc) {
		this.arrLoc = arrLoc;
	}

	/**
	 * get flight date
	 * 
	 * @return flight date
	 */
	public Date getFlightDate() {
		return flightDate;
	}

	/**
	 * set flight date
	 * 
	 * @param flightDate
	 */
	public void setFlightDate(Date flightDate) {
		this.flightDate = flightDate;
	}

	/**
	 * get flight class
	 * 
	 * @return flight class
	 */
	public String getFlightClass() {
		return flightClass;
	}

	/**
	 * set flight class
	 * 
	 * @param flight
	 *            class
	 */
	public void setflightClass(String flightClass) {
		this.flightClass = flightClass;
	}

	/**
	 * get flight preference
	 * 
	 * @return preference
	 */
	public String getPreference() {
		return preference;
	}

	/**
	 * set flight preference
	 * 
	 * @param flight
	 *            preference
	 */
	public void setPreference(String preference) {
		this.preference = preference;
	}

}
