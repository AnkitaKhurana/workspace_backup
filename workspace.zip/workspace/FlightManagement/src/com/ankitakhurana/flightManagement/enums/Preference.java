package com.ankitakhurana.flightManagement.enums;

public enum Preference {
	FARE, BOTH
}
