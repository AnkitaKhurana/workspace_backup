package com.ankitakhurana.flightManagement.enums;

public enum FlightClassType {
	E, EB
}
