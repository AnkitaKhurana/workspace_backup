package com.ankitakhurana.flightManager.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ankitakhurana.flightManagement.models.Flight;
import com.ankitakhurana.flightManagement.models.SearchParams;
import com.ankitakhurana.flightManagement.models.User;
import com.ankitakhurana.flightManagment.services.FlightService;

@Controller
public class FlightController {

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView searchFlight() {
		ModelAndView mav = new ModelAndView("flightSearch.jsp");
		mav.addObject("users", new User());
		mav.addObject("search", new SearchParams());
		return mav;

	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-mm-yyyy");
		sdf.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}

	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public ModelAndView searchFlightPost(@ModelAttribute("search") @Validated SearchParams searchParams,
			BindingResult result, Model model) {

		if (result.hasErrors()) {
			ModelAndView mav = new ModelAndView("error.jsp");
			return mav;
		} else {

			List<Flight> flights = FlightService.getFlights(searchParams);

			ModelAndView mav = new ModelAndView("result.jsp");
			mav.addObject("flights", flights);
			return mav;
		}
	}
}
