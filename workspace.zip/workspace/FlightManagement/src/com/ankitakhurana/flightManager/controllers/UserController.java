package com.ankitakhurana.flightManager.controllers;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ankitakhurana.flightManagement.models.User;
import com.ankitakhurana.flightManagment.services.UserService;

@Controller
public class UserController {

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView validateUser(@Valid User user, BindingResult result) {

		System.out.println(result.hasErrors());
		if (result.hasErrors()) {
			System.out.println(user);
			ModelAndView mav = new ModelAndView("error.jsp");
			return mav;
		} else {

			User userFound = UserService.findUser(user);
			if (userFound != null) {
				ModelAndView mav = new ModelAndView("redirect:search");
				return mav;
			} else {
				return getMethod();
			}

		}

	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView getMethod() {
		ModelAndView mav = new ModelAndView("index.jsp");
		// mav.addObject("user", new User());
		return mav;
	}

}
