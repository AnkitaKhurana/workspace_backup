package com.ankitakhurana.flightManager;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

@Configuration
@ComponentScan({"com.ankitakhurana", "com.ankitakhurana.flightManager"})
public class ApplicationConfiguration {

	   @Bean
	   public LocalValidatorFactoryBean getValidator() {
	       return new LocalValidatorFactoryBean();
	   }
	   
	   @Bean
	   public ResourceBundleMessageSource getMessageSource() {
	       return new ResourceBundleMessageSource();
	   }
//	<bean id="validator"
//			class="org.springframework.validation.beanvalidation.LocalValidatorFactoryBean">
//			<property name="validationMessageSource" ref="messageSource" />
//		</bean>
//	 @Bean
//	    public LocalValidatorFactoryBean validator() {
//	        return new validator();
//	    }
}
