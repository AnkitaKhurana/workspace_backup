
import java.sql.*;
//import com.mysql.jdbc.Driver;
public class mainApp {

	
	public static void main (String[] args)throws Exception{
		
		String url = "jdbc:mysql://localhost:3306/ankita";
		String username = "root";
		String password = "";
		String query = "SELECT * FROM Student where id = 3 ;";
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, password);
		Statement s = con.createStatement();
		ResultSet rs = s.executeQuery(query); //DQL
		// executeUpdate -> insert queried (DML)
		
		while(rs.next()){
			System.out.print(rs.getString(1));
		}
		s.close();
		con.close();
	}
}
