package com.ankitakhurana.constants;

public class ImageConstants {

	public static final int convertToMb = 1024*1024;
}
