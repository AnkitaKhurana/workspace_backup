package com.ankitakhurana.entities;

public enum FlightClassType {
	E, B, EB
}
