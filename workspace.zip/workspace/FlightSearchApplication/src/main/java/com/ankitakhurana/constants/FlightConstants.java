package com.ankitakhurana.constants;

public class FlightConstants {

	public final static String DIRECTORY = "./src/main/resources";
}
