package com.ankitakhurana.springdemo.springdemo;

import org.springframework.stereotype.Component;

@Component
public class Maruti extends Car{

	
}
