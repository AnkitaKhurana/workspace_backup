package com.ankitakhurana.springdemo.springdemo;


public class Car {

	void run(){
		System.out.print("runnnigg...");
	}
	
}
