package com.ankitakhurana.hrManagement.configs;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({"com.ankitakhurana", "com.ankitakhurana.hrManagement"})
public class ApplicationConfiguration {

}
